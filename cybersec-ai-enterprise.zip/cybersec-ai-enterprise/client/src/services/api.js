import axios from 'axios';
const api=axios.create({baseURL:import.meta.env.VITE_API_URL || 'http://localhost:5000/api'});
api.interceptors.request.use(cfg=>{ const token=localStorage.getItem('soc_token'); if(token) cfg.headers.Authorization=`Bearer ${token}`; return cfg; });
export default api;
