import React,{createContext,useContext,useState} from 'react'; import api from '../services/api.js';
const AuthContext=createContext(null); export const useAuth=()=>useContext(AuthContext);
export function AuthProvider({children}){ const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem('soc_user')||'null'));
 async function login(email,password,otp){ const {data}=await api.post('/auth/login',{email,password,otp}); localStorage.setItem('soc_token',data.token); localStorage.setItem('soc_user',JSON.stringify(data.user)); setUser(data.user); }
 async function register(payload){ const {data}=await api.post('/auth/register',payload); localStorage.setItem('soc_token',data.token); localStorage.setItem('soc_user',JSON.stringify(data.user)); setUser(data.user); }
 function logout(){ localStorage.removeItem('soc_token'); localStorage.removeItem('soc_user'); setUser(null); }
 return <AuthContext.Provider value={{user,login,register,logout,hasRole:(...r)=>user&&r.includes(user.role)}}>{children}</AuthContext.Provider> }
