import {Router} from 'express'; import {z} from 'zod'; import {validate} from '../middleware/validate.js'; import {protect} from '../middleware/auth.js'; import * as c from '../controllers/auth.controller.js';
const r=Router();
r.post('/register',validate(z.object({name:z.string().min(2),email:z.string().email(),password:z.string().min(8),role:z.enum(['admin','analyst','viewer']).optional()})),c.register);
r.post('/login',validate(z.object({email:z.string().email(),password:z.string().min(1),otp:z.string().optional()})),c.login);
r.post('/forgot-password',validate(z.object({email:z.string().email()})),c.forgotPassword);
r.post('/2fa/setup',protect,c.setup2FA); r.post('/2fa/verify',protect,c.verify2FA);
export default r;
