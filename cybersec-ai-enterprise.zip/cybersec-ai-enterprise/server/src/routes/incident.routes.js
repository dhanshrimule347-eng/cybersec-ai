import {Router} from 'express'; import Incident from '../models/Incident.js'; import {protect,allowRoles} from '../middleware/auth.js'; import {summarizeIncident,recommendations} from '../ai/threatEngine.js';
const r=Router(); r.use(protect);
r.get('/',async(req,res)=>res.json(await Incident.find(req.query.severity?{severity:req.query.severity}:{}).sort('-createdAt').limit(100)));
r.post('/',allowRoles('admin','analyst'),async(req,res)=>{ const count=await Incident.countDocuments(); const doc=new Incident({...req.body,incidentNumber:1000+count}); doc.aiSummary=summarizeIncident(doc); doc.recommendations=recommendations(doc); await doc.save(); res.status(201).json(doc); });
r.patch('/:id',allowRoles('admin','analyst'),async(req,res)=>res.json(await Incident.findByIdAndUpdate(req.params.id,req.body,{new:true})));
r.delete('/:id',allowRoles('admin'),async(req,res)=>{ await Incident.findByIdAndDelete(req.params.id); res.json({message:'Incident deleted'}); });
export default r;
