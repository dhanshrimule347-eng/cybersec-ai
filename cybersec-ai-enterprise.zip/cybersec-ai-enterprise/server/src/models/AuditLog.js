import mongoose from 'mongoose';
const AuditLogSchema = new mongoose.Schema({ actor:{type:mongoose.Schema.Types.ObjectId,ref:'User'}, action:String, resource:String, metadata:Object, ip:String },{timestamps:true});
export default mongoose.model('AuditLog', AuditLogSchema);
