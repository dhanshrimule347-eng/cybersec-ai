import mongoose from 'mongoose';
const IOCSchema = new mongoose.Schema({ type:{type:String,enum:['ip','domain','url','hash','email'],required:true}, value:{type:String,required:true,index:true}, source:String, reputation:Number, tags:[String], lastChecked:Date, rawIntel:Object },{timestamps:true});
export default mongoose.model('IOC', IOCSchema);
