import mongoose from 'mongoose';
const IncidentSchema = new mongoose.Schema({
  incidentNumber:{type:Number,index:true}, title:{type:String,required:true}, description:String, category:{type:String,index:true},
  severity:{type:String,enum:['critical','high','medium','low'],default:'medium',index:true}, status:{type:String,enum:['open','investigating','contained','resolved'],default:'open',index:true},
  riskScore:{type:Number,min:0,max:100,default:50}, sourceIp:String, destinationIp:String, geo:{country:String,city:String,lat:Number,lng:Number},
  iocs:[{type:{type:String},value:String,reputation:Number}], aiSummary:String, recommendations:[String], assignedTo:{type:mongoose.Schema.Types.ObjectId,ref:'User'}
},{timestamps:true});
export default mongoose.model('Incident', IncidentSchema);
