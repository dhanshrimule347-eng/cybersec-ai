import mongoose from 'mongoose';
const ThreatLogSchema = new mongoose.Schema({
  source:{type:String,enum:['firewall','server','ids','endpoint','cloud'],default:'server'}, raw:String, eventType:String, sourceIp:String, destinationIp:String,
  severity:{type:String,enum:['critical','high','medium','low'],default:'low'}, riskScore:Number, anomalyScore:Number, parsed:Object
},{timestamps:true});
export default mongoose.model('ThreatLog', ThreatLogSchema);
