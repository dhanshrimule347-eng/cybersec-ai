import mongoose from 'mongoose';
const UserSchema = new mongoose.Schema({
  name:{type:String,required:true,trim:true}, email:{type:String,required:true,unique:true,lowercase:true,index:true}, passwordHash:{type:String,required:true},
  role:{type:String,enum:['admin','analyst','viewer'],default:'viewer'}, isActive:{type:Boolean,default:true}, twoFactorEnabled:{type:Boolean,default:false}, twoFactorSecret:String,
  resetPasswordToken:String, resetPasswordExpires:Date, lastLogin:Date
},{timestamps:true});
export default mongoose.model('User', UserSchema);
