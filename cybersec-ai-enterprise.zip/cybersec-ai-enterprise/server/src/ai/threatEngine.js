const badPorts = ['22','23','3389','445','3306'];
export function predictRisk(log){
  let score = 20;
  const text = `${log.raw || ''} ${log.eventType || ''}`.toLowerCase();
  if(text.includes('failed password') || text.includes('brute')) score += 25;
  if(text.includes('malware') || text.includes('ransomware')) score += 45;
  if(text.includes('ddos') || text.includes('syn flood')) score += 35;
  if(text.includes('exfiltration') || text.includes('large outbound')) score += 40;
  if(badPorts.some(p => text.includes(`:${p}`) || text.includes(`port ${p}`))) score += 10;
  return Math.min(100, score);
}
export function detectAnomaly(log, baseline={avgRisk:35}){ const risk=predictRisk(log); return { anomalyScore: Math.min(100, Math.abs(risk-baseline.avgRisk)*1.6), isAnomaly:risk>70 }; }
export function summarizeIncident(incident){ return `AI summary: ${incident.category || 'Security'} event from ${incident.sourceIp || 'unknown source'} with ${incident.severity} severity and risk score ${incident.riskScore}/100.`; }
export function recommendations(incident){
  const base=['Validate affected assets','Preserve logs for investigation','Check related IOCs in threat intelligence feeds'];
  if(incident.severity === 'critical') base.unshift('Escalate to SOC lead immediately');
  if(incident.sourceIp) base.push(`Temporarily block ${incident.sourceIp} if confirmed malicious`);
  return base;
}
