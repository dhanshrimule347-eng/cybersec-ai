import jwt from 'jsonwebtoken';
import User from '../models/User.js';
export async function protect(req,res,next){
  const token = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.split(' ')[1] : null;
  if(!token) return res.status(401).json({message:'Authentication required'});
  try{ const decoded = jwt.verify(token, process.env.JWT_SECRET); req.user = await User.findById(decoded.id).select('-passwordHash -twoFactorSecret'); next(); }
  catch{ return res.status(401).json({message:'Invalid or expired token'}); }
}
export const allowRoles = (...roles)=>(req,res,next)=> roles.includes(req.user.role) ? next() : res.status(403).json({message:'Insufficient permissions'});
