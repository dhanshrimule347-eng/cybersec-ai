# MongoDB Schema

## users
name, email, passwordHash, role, isActive, twoFactorEnabled, twoFactorSecret, resetPasswordToken, resetPasswordExpires, lastLogin, timestamps.

## incidents
incidentNumber, title, description, category, severity, status, riskScore, sourceIp, destinationIp, geo, iocs, aiSummary, recommendations, assignedTo, timestamps.

## threatlogs
source, raw, eventType, sourceIp, destinationIp, severity, riskScore, anomalyScore, parsed, timestamps.

## auditlogs
actor, action, resource, metadata, ip, timestamps.

## iocs
type, value, source, reputation, tags, lastChecked, rawIntel, timestamps.
