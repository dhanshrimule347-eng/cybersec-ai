# AWS Deployment Guide

1. Build Docker images for `client` and `server`.
2. Push images to Amazon ECR.
3. Use MongoDB Atlas or Amazon DocumentDB for database storage.
4. Deploy backend to ECS Fargate or EC2 with Docker.
5. Deploy frontend to S3 + CloudFront or ECS.
6. Use AWS ALB with HTTPS certificate from ACM.
7. Store secrets in AWS Secrets Manager or SSM Parameter Store.
8. Enable CloudWatch logs for API and container metrics.
9. Add WAF rules for API protection and rate-limit abuse.
10. Configure backup and retention for database and reports.
