# API Endpoints

## Auth
- POST `/api/auth/register`
- POST `/api/auth/login`
- POST `/api/auth/forgot-password`
- POST `/api/auth/2fa/setup`
- POST `/api/auth/2fa/verify`

## Dashboard
- GET `/api/dashboard/summary`
- GET `/api/dashboard/charts`

## Incidents
- GET `/api/incidents`
- POST `/api/incidents` Admin/Analyst
- PATCH `/api/incidents/:id` Admin/Analyst
- DELETE `/api/incidents/:id` Admin only

## Threat AI
- POST `/api/threats/analyze`

## Logs
- GET `/api/logs`
- POST `/api/logs/upload`

## Threat Intelligence
- GET `/api/intel/reputation/:ioc`

## Reports
- GET `/api/reports/incidents.pdf`
- GET `/api/reports/incidents.xlsx`
