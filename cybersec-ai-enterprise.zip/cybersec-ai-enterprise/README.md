# CyberSec AI Enterprise SOC Platform

Professional MERN upgrade of the original single-file CyberSec AI dashboard.

## Features
- React responsive SOC UI with dark/light theme
- JWT auth, bcrypt password hashing, RBAC roles: Admin, Analyst, Viewer
- 2FA setup with TOTP QR code support
- Node.js + Express REST API with Helmet, CORS, rate limiting, validation
- MongoDB models for users, incidents, threat logs, IOCs, audit logs
- AI threat engine for risk scoring, anomaly detection, recommendations, and summaries
- VirusTotal, AbuseIPDB, and Shodan integration stubs
- Log upload and parsing
- PDF and Excel report export
- Docker Compose setup

## Run locally
```bash
cp .env.example .env
npm install
npm --prefix client install
npm --prefix server install
docker compose up -d mongo
npm run seed
npm run dev
```

Open `http://localhost:5173`.

Demo login: `admin@cybersec.io` / `Demo@1234`

## Production checklist
- Use a strong JWT secret and rotate keys regularly.
- Use MongoDB Atlas or hardened self-hosted MongoDB with authentication enabled.
- Put API behind HTTPS using Nginx or AWS ALB.
- Restrict CORS to your frontend domain.
- Store API keys in AWS Secrets Manager or SSM Parameter Store.
- Enable centralized logs with CloudWatch.
- Add SIEM integrations such as Splunk, Wazuh, Elastic, or Sentinel.
